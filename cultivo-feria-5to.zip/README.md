# 🌿 Cultivo - Feria de Ciencias 5to

Un juego educativo de cultivo virtual para la feria de ciencias, con sustratos, semillas y cuidados de la planta.  
Incluye una infografía de 50 retos para ahorrar energía.

## 🚀 Cómo usar
1. Abre el archivo `index.html` en tu navegador.
2. Selecciona un sustrato y una semilla.
3. Usa los botones de agua y sol para cuidar tu planta.
4. Si seleccionas un sustrato inadecuado, la planta morirá.
5. Haz clic en el botón `i` para ver la infografía de ahorro energético.

## 📂 Estructura
- **index.html** → Contiene el código del juego.
- **infografia-twenergy.jpg** → Imagen con consejos de ahorro energético.
- **README.md** → Este documento con instrucciones.

## 🛠 Tecnologías
- HTML5
- CSS3
- JavaScript

## 📄 Licencia
Este proyecto está bajo la licencia MIT. Puedes usarlo y modificarlo libremente.
